package models;

public interface Entidade {

	
}
