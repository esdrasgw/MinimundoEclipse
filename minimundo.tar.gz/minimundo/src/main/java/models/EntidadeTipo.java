package models;

public enum EntidadeTipo {
	CLIENTE,
	ENDERECO,
	PRODUTO,
	ENTREGA
}
