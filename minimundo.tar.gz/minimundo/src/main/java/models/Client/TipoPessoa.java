package models.Client;

public enum TipoPessoa {
	FISICA,
	JURIDICA
}
