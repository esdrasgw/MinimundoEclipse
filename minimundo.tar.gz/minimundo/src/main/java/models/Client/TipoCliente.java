package models.Client;

public enum TipoCliente {
	NULO,
	DESTINATARIO,
	REMETENTE
}
