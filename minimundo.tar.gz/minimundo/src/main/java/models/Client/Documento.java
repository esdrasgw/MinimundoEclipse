package models.Client;

public enum Documento {
	CPF,
	CNPJ
}
